declare interface ISpFxAadHttpClientWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpFxAadHttpClientWebPartStrings' {
  const strings: ISpFxAadHttpClientWebPartStrings;
  export = strings;
}
